# Installation dans Claude Code Web

Ce package est prévu pour Claude Code dans le navigateur (`claude.ai/code`).
Aucune application locale et aucune installation dans `~/.claude/skills/` ne sont nécessaires.

## Méthode recommandée

1. Ajoutez le fichier ZIP à la racine de votre dépôt GitHub.
2. Ouvrez ce dépôt dans Claude Code Web.
3. Collez la commande suivante dans la conversation :

> Décompresse `premium-landing-page-designer-web.zip` à la racine du dépôt. Vérifie que le fichier `.claude/skills/premium-landing-page-designer/SKILL.md` existe, conserve tous les dossiers `references`, `examples` et `scripts`, supprime ensuite le ZIP du dépôt, puis crée un commit nommé `Add premium landing page designer skill`. Ne modifie aucun autre fichier.

4. Une fois les changements commités, ouvrez une nouvelle session Claude Code Web sur ce dépôt.
5. Lancez le skill avec :

```text
/premium-landing-page-designer
```

## Vérification

La structure finale du dépôt doit contenir :

```text
.claude/
└── skills/
    └── premium-landing-page-designer/
        ├── SKILL.md
        ├── references/
        ├── examples/
        └── scripts/
```

## Exemple d’utilisation

```text
/premium-landing-page-designer

Analyse les assets présents dans le dépôt et conçois une landing page premium,
fluide et interactive pour mon produit cosmétique. Commence par deux directions
artistiques distinctes, recommande la meilleure, puis construis la page complète.
Les animations et la 3D doivent servir la compréhension et la conversion, avec une
version mobile légère. N’invente aucun avis, résultat, ingrédient ou certification.
```
